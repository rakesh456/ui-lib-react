import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';

it('renders without crashing', () => {
  const div = document.createElement('div');
  const options = {"displayFormat": "DD/MM/YYYY", "iconAlignment":"left", "showErrorMessage": true, "dateStringAlignment": "left", "lowerLimit": "11/09/2020", "upperLimit": "29/12/2024", "validationMessages": [{"inValidFormat": "Invalid DOB"}, { "outsideRange": ""}] , "isDisabled": false, "showButtons": false, "dateButtonPrimary": "Ok", "showClearIcon": false, "manualEntry": true, "disabledList": ["25/12/2020", "15/10/2024", "01/11/2020", "20/11/2020"], "indicatorList": [{ "dates": ["01/10/2021","02/11/2020"], "color": "#333" }, { "dates": ["02/09/2019","01/08/2019"], "color": "#ff0000" }]};
  ReactDOM.render(<App options={options} />, div);
  ReactDOM.unmountComponentAtNode(div);
});
