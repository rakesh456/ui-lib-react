export const KEY_CODES = {
    ESCAPE:  27,
    SPACE:  32,
    COMMA:  44,
    NINE:  57,
}